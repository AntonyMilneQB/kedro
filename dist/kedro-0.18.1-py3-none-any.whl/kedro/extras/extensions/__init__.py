"""
This module contains an IPython extension.
"""
